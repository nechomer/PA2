package IC;

public class Compiler {
    public static void main(String[] args)
    {
    }
}

package IC.Parser;

public class LexicalError extends Exception
{
    public LexicalError(String message) {
     // do something
    }
}

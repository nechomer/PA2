package IC.Parser;

public class sym {
  public static final int LP = 1;
}

package IC.Parser;

public class SyntaxError extends Exception {
}
